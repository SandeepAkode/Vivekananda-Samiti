<div class="wrapper2">
  <h2 class = heading><strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> Contact us</strong>
    <hr style="border: 1px solid black"/>
  </h2>

  <div id="contact-page" class="page">

		</br></br>
		<b>Head, Vivekananda Samiti</b></br>
		Shubhadip Mitra : +91-9935600145</br></br>
		<b>Co-ordinators, Vivekananda Samiti</b></br>
		Ajay Vikram : +91-8009468187</br>  
		Arnab Pal   : +91-8953433413</br></br>
		<b>Co-ordinators, VYLC 2014</b></br>
		Harsh Vardhan : +91-9506405124</br>  
		Raghunandan   : +91-8765674651</br></br>
		<b>Co-ordinators, College Event Team </b></br>
		Sunanya : +91-9450532858</br>  
		Sunil   : +91-9454812713</br></br>
		<b>Co-ordinators, School Event Team </b></br>
		Kanupriya : +91-9695905554</br>  
		Ram Murthy: +91-7784031436</br></br>
		<b>Co-ordinator, Hospitality Team</b></br>
		Hitesh : +91-8960437205</br></br>
		<b>Co-ordinator, Professional Relations Team</b></br>
		Subhadip Mitra : +91-9935600145</br></br>

		<h1 class = headng style="color:black;">
			<b>Vivekananda Samiti, IIT Kanpur</b>
		</h1>

		<b>Web site:</b><a href="http://www.iitk.ac.in/vs" class="linkcolor">http://www.iitk.ac.in/vs </a><br/>
 		<b>Email:</b> <a href="mailto:vsamiti@iiitk.ac.in" class="linkcolor">vsamiti@iiitk.ac.in</a><br/>
 		<b>Ph:</b> +91-9616096096<br/>

 		<br/>

 		You may also join us on Youtube and Facebook, to keep yourself updated with the latest <br/>
 		Facebook Page:  <a target="_blank" href="https://www.facebook.com/vsiitk" class="linkcolor"><strong>www.facebook.com/vsiitk</strong></a><br>
 		Facebook Group: <a target="_blank" href="https://www.facebook.com/groups/vsiitk/" class="linkcolor"><strong>www.facebook.com/groups/vsiitk</strong></a><br>
 		Youtube Channel:<a target="_blank" href="http://www.youtube.com/user/vsiitk" class="linkcolor"><strong>www.youtube.com/user/vsiitk
		</strong></a> <br>
	</div>
</div>