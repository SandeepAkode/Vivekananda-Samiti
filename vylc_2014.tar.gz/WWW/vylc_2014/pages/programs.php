<style>
 .wrapper2 {
  margin-left: 61px;
 }

 .seq {
  margin-top: 40px;
  margin-bottom: 15px;
 }
 .seq span{
  border-bottom: 2px solid brown;
 }
 </style>

<div class="wrapper2">
  <h2 class = heading><strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> Programs</strong>
    <hr style="border: 1px solid black"/>
    </h2>

    <div id="programs-page" class="page">
      <div class="seq"><span>Inspirational Talks by Eminent Personalities</span><br/>
      </div>
      <div class="seq"><span>Soft Skill Workshops</span><br/>
      </div>
      <div class="seq"><span>Youth Cafe</span><br/>
      </div>
    <div class="seq"><span>Social Entrepreneurial workshop </span><br/>
      </div>
  </div>
</div>