<style>
 .wrapper2 {
 	margin-left: 61px;
}

.seq {
 	margin-top: 40px;
 	margin-bottom: 15px;
}
.seq span{
 	border-bottom: 2px solid brown;
}

.change{
	color: rgb(100, 2, 4);
}


</style>

<script type="text/javascript" src="plugins/tileslideshow/plugin.js">
</script>
<script type="text/javascript" src = "js/jquery.slimscroll.js"></script>
 <script type="text/javascript" src="../jquery-1.3.2.js"></script>
   

<div class="wrapper2">
	<h2 class = heading >
		<strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> 
	 	Talks & Workshops
	 	</strong> 
	  <hr style="border: 1px solid black"/>
	</h2>
	<div id="workshops-page" class="page">
	<!--	<h2 style="color:black;margin-left: 24px;">To be uploaded soon ...</h2> -->
	</div>
 
        <span style='font-size:25px; margin-left:500px; margin-top:0px; border-bottom: 2px solid rgb(100, 2, 4)'>
          Talks 
        </span></br></br></br>
  
  <div style="border: 2px solid black">  
  	<!-- <a  href="?/speakers" id="tileSlideshow0-2-55" class="tile tileSlideshow " style="
        margin-top:45px; margin-left:310px;
	      width:219px; height:300px;
	      background:#6950ab;"  data-pos='45-310-300'  data-n=0> 
    
        <div class='imgWrapperBack' style="width: 219px; height:300px"></div>
        <div class='imgWrapper' style="width: 219px; height:300px"><img src="img\/features\/1.jpg"; style="height: 100%; width:100%" margin-left:2em; /></div>
   
        <div class='imgText'>PVC Bana Singh</div>   
        <script>slideshowTiles["tileSlideshow0-2-55"] = [["img\/features\/1.jpg","img\/features\/2.jpg","img\/features\/3.jpg","img\/features\/7.jpg","img\/features\/4.jpg","img\/features\/5.jpg","img\/features\/6.jpg","img\/features\/tabla.jpg",],["","","",""],["PVC Bana Singh","Rajendra Singh","Anshu Gupta ","Sobhit Mahur","Arunima Sinha","Bhakti Sharma","M.Pramod Kumar", "Rimpa Shiva"],"slide-right, slide-up, slide-down,slide-left",4000]</script>
    
        <div class='tileLabelWrapper top' style='border-top-color:#FF8000;'><div class='tileLabel top'>Speakers</div></div> 
      </a>
    -->

      <span style='font-size:25px; margin-left:31px; margin-top:0px; border-bottom: 2px solid black'>Day 1</span></br>

     
       <p style="font-size: 11.5pt; margin-left:31px; color:black;">Friday, Jan.10th, 2014</br>
			Time: 6-7:30 pm</br>
			Venue: L-7, Lecture Hall Complex, IIT Kanpur</br>
			Theme: <b>Service with Fearlessness</b></br>
			<b>Speakers</b>:<span style='color: rgb(139, 3, 5);'><a  href="?/speakers/#day11" style="color: rgb(139, 3, 5); text-decoration:none;">PVC Bana Singh</a> and <a  href="?/speakers/#day12" style="color: rgb(139, 3, 5); text-decoration:none;">Jalpurush Rajendra Singh</a></span>
		</p></br>

     
    <div id="photoShow">
        <div class="current1">
            <img src="img/features/sch/1.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:15px; width:150px ; height:152px;" class="gallery" />
        </div>
        <div>
            <img src="img/features/sch/2.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:15px; width:150px ; height:152px;" class="gallery" />
        </div>
        
    </div>
 
		  
	</div></br></br>

<div style="border: 2px solid black"> 
  <span style='font-size:25px; margin-left:31px; margin-top:0px;border-bottom: 2px solid black'>Day 2</span></br>
  	<p style="font-size: 11.5pt; margin-left:31px; color:black;">Saturday, Jan.11th, 2014</br>
			Time: 3-5 pm</br>
			Venue: L-16, Lecture Hall Complex, IIT Kanpur</br>
			Theme: <b>Leadership and Social Entrepreneurship</b></br>
			<b>Speakers</b>:<span style='color: rgb(139, 3, 5);'><a  href="?/speakers/#day21" style="color: rgb(139, 3, 5); text-decoration:none;">Anshu Gupta</a> and <a  href="?/speakers/#day22" style="color: rgb(139, 3, 5); text-decoration:none;">Shobhit Mathur</a></span>  
		</p></br>

		<div id="photoShow1">
        <div class="current1">
            <img src="img/features/sch/3.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:15px; width:150px ; height:152px;" class="gallery" />
        </div>
        <div>
            <img src="img/features/sch/7.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:15px; width:150px ; height:152px;" class="gallery" />
        </div>
        
    </div>

   
		
	</div></br></br>

<div style="border: 2px solid black"> 
  <span style='font-size:25px; margin-left:31px; margin-top:0px;border-bottom: 2px solid black'>Day 3</span></br>
  	<p style="font-size: 11.5pt; margin-left:31px; color:black;">Sunday, Jan.12th, 2014 (National Youth Day)</br>
			Time: 5:30 pm-7:30 pm</br>
			Venue: L-7, Lecture Hall Complex, IIT Kanpur</br>
			Theme: <b>Swami Vivekananda and Human Excellence</b></br>
			<b>Speakers</b>:</br>
			<span style='color: rgb(139, 3, 5);'><a  href="?/speakers/#day31" style="color: rgb(139, 3, 5); text-decoration:none;">Arunima Sinha</span></a> - <b>"Journey from the Railway tracks to the Mt. Everest"</b></br>
			<span style='color: rgb(139, 3, 5);'><a  href="?/speakers/#day32" style="color: rgb(139, 3, 5); text-decoration:none;">Bhakti Sharma</span></a> - <b>"Lessons learnt from the seven seas"</b></br>
			<span style='color: rgb(139, 3, 5);'><a  href="?/speakers/#day33" style="color: rgb(139, 3, 5); text-decoration:none;">M. Pramod Kumar</span></a> - <b>"Swami Vivekananda - The icon of Youth and Self-confidence"</b>
  	</p></br></br>

  	 <div id="photoShow2">
        <div class="current1">
            <img src="img/features/sch/4.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:45px; width:150px ; height:152px;" class="gallery" />
        </div>
        <div>
            <img src="img/features/sch/5.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:45px; width:150px ; height:152px;" class="gallery" />
        </div>
        <div>
            <img src="img/features/sch/6.jpg" alt="Photo Gallery" style="margin-left:14px; margin-top:45px; width:150px ; height:152px;" class="gallery" />
        </div>
        
    </div>
 
  	</div></br></br>

<script type="text/javascript" src="js/jq.js"></script>
 
 	 <span style='font-size:25px; margin-left:500px; margin-top:12px; border-bottom: 2px solid rgb(100, 2, 4)'>
         Workshops 
        </span></br></br></br>
   
<div style="border: 2px solid black"> 

	<span style='font-size:25px; margin-left:31px; margin-top:0px; border-bottom: 2px solid black'>Workshop on Self Expression</span>
		<p style="font-size: 11.5pt; margin-left:31px; color:black;">Session1: Saturday, Jan.11, 2014 10:30 am-1 pm<br/>
			Session2: Sunday, Jan.12, 2014 10:30 am-1 pm<br/>
			Venue: L-1, LHC<br/></br>
			<b>Topics</b>: </br>
			<ul  style="font-size: 11.5pt; margin-left:58px; color:black;">
				<li>Understand how self-expression matters for your career</li>
				<li>Self-inventory</li>
				<li>Empathy</li>
				<li>Basics of communication</li>
				<li>Role of language</li>
				<li>Prototype yourself</li>
				<li>Marketing yourself</li>
				<li>How it matters in the job-market</li>
				<li>Self-expression, Communication, Group-Discussion and Resume</li>
			</ul>
		</p></br>
</div></br></br>

<div style="border: 2px solid black">  	
 	<span style='font-size:25px; margin-left:31px; margin-top:0px;border-bottom: 2px solid black'>Workshop on Enlightened Citizenship - Youth Cafe</span>
 		<p style="font-size: 11.5pt; margin-left:31px; color:black;">Saturday, 11th Jan., 2014<br/>
		Batch 1: 10 am -1 pm<br/>
		Batch 2: 2 pm - 5 pm<br/>
		Venue: L-15, LHC<br/>
		<b>Topic</b>: TBA
		</p></br>
 </div></br></br>
</div>