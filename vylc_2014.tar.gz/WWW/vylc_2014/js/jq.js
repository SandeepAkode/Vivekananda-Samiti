  $(function() {
            // create the image rotator
            setInterval("rotateImages()", 2000);
            setInterval("rotateImagesOne()", 2000);
             setInterval("rotateImagesTwo()", 2000);
        });

        function rotateImages() {
            var oCurPhoto = $('#photoShow div.current1');
            var oNxtPhoto = oCurPhoto.next();
            if (oNxtPhoto.length == 0)
                oNxtPhoto = $('#photoShow div:first');

            oCurPhoto.removeClass('current1').addClass('previous');
            oNxtPhoto.css({ opacity: 0.0 }).addClass('current1').animate({ opacity: 1.0 }, 1000,
                function() {
                    oCurPhoto.removeClass('previous');
                });
        }



        function rotateImagesOne() {
            var oCurPhoto = $('#photoShow1 div.current1');
            var oNxtPhoto = oCurPhoto.next();
            if (oNxtPhoto.length == 0)
                oNxtPhoto = $('#photoShow1 div:first');

            oCurPhoto.removeClass('current1').addClass('previous');
            oNxtPhoto.css({ opacity: 0.0 }).addClass('current1').animate({ opacity: 1.0 }, 1000,
                function() {
                    oCurPhoto.removeClass('previous');
                });
        }

        function rotateImagesTwo() {
            var oCurPhoto = $('#photoShow2 div.current1');
            var oNxtPhoto = oCurPhoto.next();
            if (oNxtPhoto.length == 0)
                oNxtPhoto = $('#photoShow2 div:first');

            oCurPhoto.removeClass('current1').addClass('previous');
            oNxtPhoto.css({ opacity: 0.0 }).addClass('current1').animate({ opacity: 1.0 }, 1000,
                function() {
                    oCurPhoto.removeClass('previous');
                });
        }


