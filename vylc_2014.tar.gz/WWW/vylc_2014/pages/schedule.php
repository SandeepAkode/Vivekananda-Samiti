 <style>
 .seq {
 	margin-top: 40px;
 	margin-bottom: 15px;
 }
 .seq span{
 	border-bottom: 2px solid brown;
 }

 #schedule-page table {
 	width: 800px;
	margin: auto;
	border-collapse: collapse;
 }

 #schedule-page th {
 	text-align: center;
 	color: brown;
 	border: 1px solid brown;
 	font-weight: bold;
 }

 #schedule-page td {
 	border: 1px solid brown;
 	text-align: center;
 	padding-top: .5em;
 	padding-bottom: .5em;
 }

/* #schedule-page .speaker {
 	padding-left: 84px;
 }

#schedule-page .date_time {
 	padding-left: 84px;
 }
#schedule-page .center {
 	text-align: center;
 }*/
 </style>

<div class="wrapper2">
<h2 class = heading><strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> Schedule</strong>
   <hr style="border: 1px solid black"/>
   </h2>
   <h2 style="color:black;margin-left: 24px;">To be uploaded soon ...</h2>
   <!--
   <div id="schedule-page" class="page">
   	<div class="seq"><span>Talk Schedule</span></div>
   	<table>
   		<col style="width:33.33%"/>
   		<col style="width:33.33%"/>
   		<col style="width:33.33%; text-align: center;"/>
   		<tr>
   			<th>Speaker</th>
   			<th>Date &amp; Time</th>
   			<th>Venue</th>
   		</tr>
		<tr>
			<td class="speaker">Dr. Kiran Bedi</td>
			<td class="date_time">10 Jan, 2:00 pm</td>
			<td class="center">Main Auditorium</td>
		</tr>
		<tr>
			<td class="speaker">Inauguration by Director</td>
			<td class="date_time">10 Jan, 6:00 pm</td>
			<td class="center">L-16</td>
		</tr>
		<tr>
			<td class="speaker">Swami Shastrajnananda</td>
			<td class="date_time">10 Jan, 6:10pm - 7pm</td>
			<td class="center">L-16</td>
		</tr>
		<tr>
			<td class="speaker">Mr. Dharam Vir</td>
			<td class="date_time">11 Jan, 6:00 pm - 6:30 pm</td>
			<td class="center">L-16</td>
		</tr>
		<tr>
			<td class="speaker">Dr. Sandeep Pandey</td>
			<td class="date_time">11 Jan, 6:45 pm - 7:15 pm</td>
			<td class="center">L-16</td>
		</tr>
		<tr>
			<td class="speaker">Mr. Amitabh Thakur</td>
			<td class="date_time">12 Jan, 5:00 pm - 6:00 pm</td>
			<td class="center">L-16</td>
		</tr>
   	</table>
   </div>
   -->
</div>
