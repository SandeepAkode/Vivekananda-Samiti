<div class="wrapper2" style="margin-left: 125px;">
<h2 class = heading><strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> Results</strong>
   <hr style="border: 1px solid black"/>
   </h2>
   <div id="results-page" class="page">
   </div>
</div>
