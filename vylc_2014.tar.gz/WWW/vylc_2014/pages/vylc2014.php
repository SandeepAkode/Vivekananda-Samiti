 <style>
 .wrapper2 {
  margin-left: 61px;
 }
</style>

<div class="wrapper2">
	<h2 class = heading><strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> About VYLC - 2014</strong>
	  <hr style="border: 1px solid black"/>
	</h2>
	 
	<div id="vylc2014-page" class="page">
		<p><b>Vivekananda Youth Leadership Convention</b> aims to inspire our students to imbibe and assert the human values in their lives. Our aim is to foster the spirit of enthusiasm, fearlessness, determination, self-belief, perseverance and service among our youth.</p>

		<p>With the focus on <b>leadership, social entrepreneurship,</b> and <b>promotion of Indian culture and integrity,</b> the Convention aspires to make our youth believe in their inherent potential. This is a very unique event, providing inspiration and permuting leadership among the youth who can be the torch bearers in the society tomorrow.</p><br/>

		The highlights of the Convention are the following: 
		<li>Inspirational talks by eminent leaders from various fields.</li>
		<li>Workshops on Leadership and Soft Skills, Social Entrepreneurship, and Enlightened Citizenship-Youth Cafe.</li>
		<li>Exciting College level events like Youth Leadership Challenge, Quiz on Indian culture and heritage, United India, Entrepreneurship Challenge, Creative Writing, to name a few.</li>
		<li>Enriching School events like Quiz, Poster Making, Extempore and Essay writing.</li>
		<li>A Special Cultural Show- A Tabla performance by “Princess of Tabla”, Ms. Rimpa Shiva.</li>
	</div>
</div>