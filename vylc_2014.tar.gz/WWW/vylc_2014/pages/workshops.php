<style>
#about-page p {
	font-size: 15px;
	text-align: justify;
}
</style>

<div class="wrapper2">
	<h2 class = heading >
		<strong><a href="javascript:window.history.back();"><img src="themes/theme_default/img/primary/arrowleft.png"/></a> 
	 	Workshops
	 	</strong> 
	  <hr style="border: 1px solid black"/>
	</h2>
	<div id="workshops-page" class="page">
	<!--	<h2 style="color:black;margin-left: 24px;">To be uploaded soon ...</h2> -->
		<div class="seq"><span>Workshop on Leadership and Soft Skills</span>
 			<p style="font-size: 11pt; color:black;">Session1: Saturday, Jan.11, 2014 10:30 am-1 pm<br/>
				Session2: Sunday, Jan.12, 2014 10:30 am-1 pm<br/>
				Venue: L-1, LHC<br/>
				Topics: TBA
			</p>
  	</div>
  	<div class="seq"><span>Workshop on Enlightened Citizenship - Youth Cafe</span>
  		<p style="font-size: 11pt; color:black;">Saturday, 11th Jan., 2014<br/>
			Batch 1: 10 am -1 pm<br/>
			Batch 2: 2 pm - 5 pm<br/>
			Venue: L-15, LHC<br/>
			Topic: TBA
			</p>
  	</div>
	</div>
</div>