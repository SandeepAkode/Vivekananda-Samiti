<h2 style="color:black;">Login with:</h2>
<table>
	<tr>
		<td style="width:300px"><button onclick="window.location.href='https://vylc-2014.appspot.com/login?provider=Google'"><img src="img/google.png"></button></td>
		<td><button onclick="window.location.href='https://vylc-2014.appspot.com/login?provider=Yahoo'"><img src="img/yahoo.png"/></button></td>
	</tr>
</table>